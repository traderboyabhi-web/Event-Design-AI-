/*!
 * Event Decor AI — embeddable widget (single file, no dependencies)
 * Embed:  one script tag with src="event-decor-ai.js" plus data-api, data-brand, data-whatsapp attributes (see README.md)
 * Options (data-* attrs or window.EventDecorConfig):
 *   api       AI render endpoint (optional; see worker.js)
 *   brand     accent colour
 *   title     panel title
 *   mode      "popup" (floating button, default) | "inline"
 *   target    element id for inline mode (default "event-decor-ai")
 *   whatsapp  number with country code for the Enquire button
 *   button    launcher label
 *   sample    "true" shows the "Sample venue" button
 * JS API: window.EventDecorAI.open() / .close()
 */
(function () {
  'use strict';
  if (window.EventDecorAI) return;

  var CFG = { api: '', brand: '#7c3aed', title: 'Visualize your event décor', mode: 'popup', target: 'event-decor-ai', whatsapp: '', button: '✨ Try décor with AI', sample: 'true' };
  var sc = document.currentScript, k;
  if (sc) for (k in sc.dataset) CFG[k] = sc.dataset[k];
  if (window.EventDecorConfig) for (k in window.EventDecorConfig) CFG[k] = window.EventDecorConfig[k];

  /* ---------- data ---------- */
  var LABEL = { ambience: 'Mood lighting', fairy: 'Fairy lights', drapes: 'Drapes', floral: 'Flower arch', balloons: 'Balloon arch', lanterns: 'Lanterns', marigold: 'Marigold strings', backdrop: 'Stage backdrop', neon: 'Neon sign', candles: 'Candles', spot: 'Spotlights' };
  var AIEL = { ambience: 'warm ambient mood lighting', fairy: 'strings of fairy lights overhead', drapes: 'elegant fabric drapes on the sides', floral: 'a lush floral arch', balloons: 'a balloon arch', lanterns: 'hanging paper lanterns', marigold: 'hanging marigold flower strings', backdrop: 'a decorated stage backdrop', neon: 'a glowing neon sign', candles: 'rows of candles on the floor', spot: 'soft spotlights' };
  var THEMES = {
    royal:    { name: 'Royal Wedding', emoji: '👑', text: 'Riya & Aman', pal: ['#f5e6c8', '#d4af37', '#a3213a', '#fff3d6'], bd: ['#7a1020', '#3d0710', '#d4af37', '#f5e6c8'], tint: 'rgba(255,170,70,0.20)', glow: '#ffd98a', on: ['drapes', 'fairy', 'floral', 'backdrop', 'candles'], ai: 'a luxurious royal Indian wedding with ivory and gold drapes, deep red roses, golden accents and warm glowing lights' },
    floral:   { name: 'Floral Garden', emoji: '🌸', text: 'Happily Ever After', pal: ['#ffc2d1', '#ff8fab', '#ffffff', '#fb6f92'], bd: ['#ffe5ec', '#ffc2d1', '#ff8fab', '#9d2b52'], tint: 'rgba(255,170,200,0.14)', glow: '#ffe3ec', on: ['floral', 'fairy', 'lanterns', 'backdrop'], ai: 'a romantic pastel garden theme with blush pink and white flowers, greenery and soft fairy lights' },
    neon:     { name: 'Neon Party', emoji: '🪩', text: 'Party Time', pal: ['#ff2bd6', '#27e0ff', '#8a2bff', '#ffffff'], bd: ['#2a0a4a', '#0b0220', '#27e0ff', '#ff2bd6'], tint: 'rgba(90,30,200,0.38)', glow: '#b86bff', on: ['neon', 'balloons', 'fairy', 'spot'], ai: 'a vibrant neon nightclub party theme with magenta, cyan and purple lighting, a glowing neon sign and balloons' },
    haldi:    { name: 'Haldi / Mehendi', emoji: '🌼', text: 'Haldi Ceremony', pal: ['#ffb300', '#ff7a00', '#ffd84d', '#2e7d32'], bd: ['#ffd84d', '#ffb300', '#2e7d32', '#6b3300'], tint: 'rgba(255,170,0,0.18)', glow: '#ffd27a', on: ['marigold', 'lanterns', 'fairy', 'floral'], ai: 'a traditional Indian haldi/mehendi theme with marigold flower strings, yellow and orange fabric, brass lanterns and fairy lights' },
    birthday: { name: 'Birthday Balloons', emoji: '🎈', text: 'Happy Birthday!', pal: ['#ff5a5f', '#ffd23f', '#3bceac', '#4d9de0'], bd: ['#4d9de0', '#2b6cb0', '#ffd23f', '#ffffff'], tint: 'rgba(255,255,255,0.04)', glow: '#fff1a8', on: ['balloons', 'backdrop', 'fairy'], ai: 'a colourful birthday party theme with a big balloon arch in red, yellow, teal and blue, and a bright backdrop' },
    corporate:{ name: 'Corporate Minimal', emoji: '🏢', text: 'Annual Meet 2026', pal: ['#e8eef7', '#3b82f6', '#93c5fd', '#ffffff'], bd: ['#16233f', '#0b1222', '#3b82f6', '#e8eef7'], tint: 'rgba(60,120,255,0.12)', glow: '#cfe3ff', on: ['backdrop', 'spot', 'ambience'], ai: 'a clean modern corporate event with a minimal branded stage backdrop, cool blue lighting and spotlights' },
    night:    { name: 'Fairy-light Night', emoji: '✨', text: 'Under the Stars', pal: ['#ffe9a8', '#ffcf70', '#ffb347', '#ffffff'], bd: ['#1a2548', '#0b1330', '#ffcf70', '#ffe9a8'], tint: 'rgba(8,14,50,0.50)', glow: '#ffe08a', on: ['fairy', 'lanterns', 'candles'], ai: 'a magical evening setting with canopies of warm fairy lights, hanging lanterns and candles, dusk ambience' }
  };

  /* ---------- helpers ---------- */
  var TAU = Math.PI * 2;
  function RNG(seed) { var s = seed % 2147483647; if (s <= 0) s += 2147483646; return function () { s = s * 16807 % 2147483647; return (s - 1) / 2147483646; }; }
  function rgb(h) { var n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function hexA(h, a) { if (h[0] !== '#') return h; var c = rgb(h); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  function shade(h, amt) { var c = rgb(h), t = amt < 0 ? 0 : 255, p = Math.abs(amt); return 'rgb(' + c.map(function (v) { return Math.round(v + (t - v) * p); }).join(',') + ')'; }
  function glow(c, x, y, r, col, a) { var g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, hexA(col, a)); g.addColorStop(1, hexA(col, 0)); c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
  function arc(c, x, y, r) { c.beginPath(); c.arc(x, y, r, 0, TAU); }
  function ell(c, x, y, rx, ry, rot) { c.beginPath(); c.ellipse(x, y, Math.abs(rx), Math.abs(ry), rot || 0, 0, TAU); }

  function archGeom(W, H, S) {
    var ax = S.ax * W, ay = S.ay * H, Rr = Math.max(20, Math.min(W * 0.24 * S.scale, ay * 0.48)), leg = Rr * 0.55;
    return { ax: ax, ay: ay, Rr: Rr, leg: leg, cy: ay - leg, total: 2 * leg + Math.PI * Rr };
  }
  function archAt(g, s) {
    if (s < g.leg) return [g.ax - g.Rr, g.ay - s];
    s -= g.leg; var al = Math.PI * g.Rr;
    if (s < al) { var th = Math.PI - s / g.Rr; return [g.ax + g.Rr * Math.cos(th), g.cy - g.Rr * Math.sin(th)]; }
    s -= al; return [g.ax + g.Rr, g.cy + s];
  }

  /* ---------- decoration layers ---------- */
  var L = {};
  L.ambience = function (c, W, H, t, S, th) {
    c.save(); c.globalAlpha = Math.min(1, S.intensity * 1.1); c.fillStyle = th.tint; c.fillRect(0, 0, W, H); c.globalAlpha = 1;
    var g = c.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,' + (0.45 * S.intensity) + ')'); c.fillStyle = g; c.fillRect(0, 0, W, H); c.restore();
  };
  L.backdrop = function (c, W, H, t, S, th, u) {
    var ax = S.ax * W, ay = S.ay * H, h = Math.min(ay * 0.8, W * 0.3 * S.scale), w = h * 1.7;
    if (w > W * 0.95) { w = W * 0.95; h = w / 1.7; }
    var x = ax - w / 2, y = ay - h, bd = th.bd;
    c.fillStyle = 'rgba(25,15,15,.6)'; c.beginPath(); c.moveTo(x - w * .04, ay); c.lineTo(x + w * 1.04, ay); c.lineTo(x + w * 1.08, ay + h * .1); c.lineTo(x - w * .08, ay + h * .1); c.closePath(); c.fill();
    c.save(); c.shadowColor = 'rgba(0,0,0,.4)'; c.shadowBlur = 18 * u;
    var g = c.createLinearGradient(x, y, x, ay); g.addColorStop(0, bd[0]); g.addColorStop(1, bd[1]); c.fillStyle = g; c.fillRect(x, y, w, h); c.restore();
    c.strokeStyle = bd[2]; c.lineWidth = 6 * u; c.strokeRect(x, y, w, h); c.lineWidth = 1.5 * u; c.strokeRect(x + 14 * u, y + 14 * u, w - 28 * u, h - 28 * u);
    var txt = S.text || th.text, size = h * 0.22; c.textAlign = 'center'; c.textBaseline = 'middle';
    do { c.font = 'italic 700 ' + size + 'px Georgia, "Times New Roman", serif'; size -= 2; } while (c.measureText(txt).width > w * 0.78 && size > 8);
    c.fillStyle = bd[3]; c.fillText(txt, ax, y + h / 2);
  };
  L.drapes = function (c, W, H, t, S, th, u) {
    var w = W * 0.2 * (0.8 + 0.35 * S.scale);
    for (var side = 0; side < 2; side++) {
      c.save(); if (side) { c.translate(W, 0); c.scale(-1, 1); }
      c.beginPath(); c.moveTo(0, 0); c.lineTo(w, 0); c.bezierCurveTo(w * .95, H * .3, w * .25, H * .55, w * .55, H); c.lineTo(0, H); c.closePath(); c.clip();
      c.globalAlpha = 0.55 + 0.4 * S.intensity; c.fillStyle = th.pal[0]; c.fillRect(0, 0, w, H); c.globalAlpha = 1;
      var n = Math.max(6, Math.round(w / (11 * u))), sw = w / n;
      for (var i = 0; i < n; i++) { var ph = Math.sin(i * 1.3 + Math.sin(t * .6 + i) * .05); c.fillStyle = ph > 0 ? 'rgba(255,255,255,' + (0.2 * ph) + ')' : 'rgba(0,0,0,' + (-0.24 * ph) + ')'; c.fillRect(i * sw, 0, sw + 1, H); }
      c.fillStyle = hexA(th.pal[1], .92); c.fillRect(0, 0, w, H * .035);
      c.restore();
    }
  };
  L.marigold = function (c, W, H, t, S, th, u) {
    var r = RNG(21), n = Math.max(6, Math.round(W / (70 * u)));
    for (var i = 0; i < n; i++) {
      var x = (i + .5) / n * W + (r() - .5) * 20 * u, len = (.2 + r() * .3) * H * (.6 + .5 * S.intensity), sw = Math.sin(t * 1.3 + i) * 3 * u;
      for (var y = 0, j = 0; y < len; y += 10 * u, j++) { c.fillStyle = th.pal[j % 3]; c.strokeStyle = 'rgba(120,50,0,.35)'; c.lineWidth = .8; arc(c, x + sw * (y / len), y, 6.2 * u); c.fill(); c.stroke(); }
    }
    c.fillStyle = th.pal[1]; for (var x3 = 0; x3 < W; x3 += 11 * u) { arc(c, x3, 2 * u, 7 * u); c.fill(); }
  };
  L.lanterns = function (c, W, H, t, S, th, u) {
    var r = RNG(5), n = Math.max(5, Math.round(W / (150 * u)));
    for (var i = 0; i < n; i++) {
      var x = (i + .5) / n * W + (r() - .5) * 60 * u, len = (.18 + r() * .28) * H, rad = (20 + r() * 12) * u, sw = Math.sin(t * 1.1 + i * 2) * .04;
      c.save(); c.translate(x, 0); c.rotate(sw);
      c.strokeStyle = 'rgba(30,20,10,.6)'; c.lineWidth = 1.2 * u; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, len); c.stroke();
      c.globalCompositeOperation = 'lighter'; glow(c, 0, len + rad, rad * 3.2, th.glow, .3 + .35 * S.intensity); c.globalCompositeOperation = 'source-over';
      var col = th.pal[i % th.pal.length], g = c.createLinearGradient(-rad, 0, rad, 0);
      g.addColorStop(0, shade(col, -.25)); g.addColorStop(.5, shade(col, .35)); g.addColorStop(1, shade(col, -.25));
      c.fillStyle = g; ell(c, 0, len + rad, rad * .8, rad); c.fill();
      c.fillStyle = 'rgba(60,40,10,.7)'; c.fillRect(-rad * .35, len - u, rad * .7, 4 * u); c.fillRect(-rad * .35, len + 2 * rad - 3 * u, rad * .7, 4 * u);
      c.strokeStyle = 'rgba(0,0,0,.15)'; c.lineWidth = 1; for (var q = -2; q <= 2; q++) { ell(c, 0, len + rad, rad * .8 * q / 2.4, rad); c.stroke(); }
      c.restore();
    }
  };
  function flower(c, x, y, rad, col, rot) {
    c.save(); c.translate(x, y); c.rotate(rot); c.fillStyle = col; c.strokeStyle = 'rgba(0,0,0,.14)'; c.lineWidth = .8;
    for (var i = 0; i < 5; i++) { c.rotate(1.2566); ell(c, rad * .55, 0, rad * .55, rad * .38); c.fill(); c.stroke(); }
    c.fillStyle = '#ffd34d'; arc(c, 0, 0, rad * .25); c.fill(); c.restore();
  }
  L.floral = function (c, W, H, t, S, th, u) {
    var g = archGeom(W, H, S), r = RNG(7), step = 8 * u * (1.4 - .6 * S.intensity), s, p;
    for (s = 0; s < g.total; s += step * .8) { p = archAt(g, s); c.save(); c.translate(p[0] + (r() - .5) * 24 * u, p[1] + (r() - .5) * 24 * u); c.rotate(r() * TAU); c.fillStyle = r() < .5 ? '#3f7d43' : '#5a9a55'; ell(c, 0, 0, 13 * u, 5 * u); c.fill(); c.restore(); }
    for (s = 0; s < g.total; s += step) { p = archAt(g, s); flower(c, p[0] + (r() - .5) * 22 * u, p[1] + (r() - .5) * 22 * u, (9 + r() * 9) * u, th.pal[(r() * 3) | 0], r() * TAU); }
  };
  function balloon(c, x, y, rad, col) {
    var g = c.createRadialGradient(x - rad * .35, y - rad * .4, rad * .1, x, y, rad * 1.1);
    g.addColorStop(0, '#ffffffcc'); g.addColorStop(.25, col); g.addColorStop(1, shade(col, -.35));
    c.fillStyle = g; ell(c, x, y, rad * .88, rad); c.fill();
    c.fillStyle = shade(col, -.3); c.beginPath(); c.moveTo(x, y + rad); c.lineTo(x - rad * .12, y + rad * 1.18); c.lineTo(x + rad * .12, y + rad * 1.18); c.fill();
  }
  L.balloons = function (c, W, H, t, S, th, u) {
    var g = archGeom(W, H, S), r = RNG(11);
    for (var s = 0; s < g.total; s += 20 * u) { var p = archAt(g, s), n = 2 + ((r() * 2) | 0); for (var i = 0; i < n; i++) balloon(c, p[0] + (r() - .5) * 34 * u, p[1] + (r() - .5) * 34 * u + Math.sin(t * 1.2 + s) * 1.2 * u, (15 + r() * 10) * u, th.pal[(r() * th.pal.length) | 0]); }
  };
  L.neon = function (c, W, H, t, S, th, u) {
    var txt = S.text || th.text, x = S.ax * W, y = S.ay * H * 0.45, size = H * 0.14;
    c.textAlign = 'center'; c.textBaseline = 'middle';
    do { c.font = '700 ' + size + 'px "Brush Script MT","Segoe Script",cursive'; size -= 2; } while (c.measureText(txt).width > W * 0.78 && size > 10);
    var fl = Math.sin(t * 23) > .96 ? .55 : 1;
    c.save(); c.globalAlpha = fl; c.shadowColor = th.pal[0]; c.shadowBlur = 34 * u * S.intensity; c.strokeStyle = th.pal[0]; c.lineWidth = 5 * u; c.strokeText(txt, x, y); c.strokeText(txt, x, y);
    c.shadowBlur = 8 * u; c.fillStyle = '#ffffff'; c.fillText(txt, x, y); c.restore();
  };
  L.candles = function (c, W, H, t, S, th, u) {
    var ax = S.ax * W, ay = S.ay * H, r = RNG(3), n = 7, span = Math.min(W * .5 * S.scale, W * .8);
    for (var i = 0; i < n; i++) {
      var x = ax - span / 2 + span * i / (n - 1), y = ay + (i % 2 ? 10 : 22) * u, h = (26 + r() * 16) * u, w = 9 * u;
      c.fillStyle = 'rgba(0,0,0,.25)'; ell(c, x, y + 2 * u, w * 1.1, 3 * u); c.fill();
      c.fillStyle = '#f6ecd6'; c.fillRect(x - w / 2, y - h, w, h);
      var fl = 1 + .15 * Math.sin(t * 9 + i * 3) + .08 * Math.sin(t * 17 + i);
      c.globalCompositeOperation = 'lighter'; glow(c, x, y - h - 6 * u, 34 * u * fl, '#ffb347', .55); c.globalCompositeOperation = 'source-over';
      c.fillStyle = '#ffd76a'; ell(c, x, y - h - 5 * u, 3 * u, 7 * u * fl); c.fill();
    }
  };
  L.spot = function (c, W, H, t, S, th, u) {
    [.3, .7].forEach(function (px, i) {
      var x = px * W + Math.sin(t * .5 + i * 3) * W * .04, g = c.createLinearGradient(px * W, 0, x, H);
      c.globalCompositeOperation = 'lighter'; g.addColorStop(0, 'rgba(255,255,255,' + (.28 * S.intensity) + ')'); g.addColorStop(1, 'rgba(255,255,255,0)');
      c.fillStyle = g; c.beginPath(); c.moveTo(px * W - 8 * u, 0); c.lineTo(px * W + 8 * u, 0); c.lineTo(x + W * .16, H); c.lineTo(x - W * .16, H); c.closePath(); c.fill(); c.globalCompositeOperation = 'source-over';
    });
  };
  L.fairy = function (c, W, H, t, S, th, u) {
    var I = S.intensity, strs = [[0, .04, .5, .20, 1, .04], [0, .13, .5, .27, 1, .13], [0, 0, .5, .30, 1, .10]];
    strs.forEach(function (s, si) {
      var x0 = s[0] * W, y0 = s[1] * H, cx = s[2] * W, cy = s[3] * H, x1 = s[4] * W, y1 = s[5] * H;
      c.strokeStyle = 'rgba(20,20,20,.45)'; c.lineWidth = Math.max(1, 1.2 * u); c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo(cx, cy, x1, y1); c.stroke();
      var n = Math.max(8, Math.round(W / (36 * u)));
      for (var i = 1; i < n; i++) {
        var p = i / n, q = 1 - p, x = q * q * x0 + 2 * q * p * cx + p * p * x1, y = q * q * y0 + 2 * q * p * cy + p * p * y1 + 8 * u, tw = .6 + .4 * Math.sin(t * 2.2 + i * 1.9 + si * 2);
        c.globalCompositeOperation = 'lighter'; glow(c, x, y, (16 + 14 * I) * u, th.glow, .5 * tw * (.5 + I / 2)); c.globalCompositeOperation = 'source-over';
        c.fillStyle = 'rgba(255,250,230,' + (.7 + .3 * tw) + ')'; arc(c, x, y, 2.6 * u); c.fill();
      }
    });
  };
  var ORDER = ['backdrop', 'drapes', 'marigold', 'lanterns', 'floral', 'balloons', 'neon', 'candles', 'spot', 'fairy'];

  function drawScene(c, W, H, t, S) {
    var th = THEMES[S.theme], u = Math.min(W, H) / 800;
    if (S.on.ambience) L.ambience(c, W, H, t, S, th);
    ORDER.forEach(function (key) { if (S.on[key]) { c.save(); L[key](c, W, H, t, S, th, u); c.restore(); } });
  }

  function sampleVenue() {
    var cv = document.createElement('canvas'); cv.width = 1280; cv.height = 720; var c = cv.getContext('2d'), i;
    var g = c.createLinearGradient(0, 0, 0, 430); g.addColorStop(0, '#cfc6b8'); g.addColorStop(1, '#e6dfd2'); c.fillStyle = g; c.fillRect(0, 0, 1280, 430);
    for (i = 0; i < 4; i++) { var x = 150 + i * 280, gg = c.createLinearGradient(x, 90, x, 320); gg.addColorStop(0, '#cde6ff'); gg.addColorStop(1, '#8fb4d8'); c.fillStyle = gg; c.fillRect(x, 90, 130, 230); c.fillStyle = '#b9ae9c'; c.fillRect(x + 62, 90, 6, 230); c.fillRect(x, 200, 130, 6); c.strokeStyle = '#a59a88'; c.lineWidth = 6; c.strokeRect(x, 90, 130, 230); }
    [0, 1160].forEach(function (px) { var pg = c.createLinearGradient(px, 0, px + 120, 0); pg.addColorStop(0, '#bdb2a0'); pg.addColorStop(.5, '#efe8da'); pg.addColorStop(1, '#bdb2a0'); c.fillStyle = pg; c.fillRect(px, 0, 120, 434); });
    var f = c.createLinearGradient(0, 430, 0, 720); f.addColorStop(0, '#8a6a49'); f.addColorStop(1, '#5b4330'); c.fillStyle = f; c.fillRect(0, 430, 1280, 290);
    c.strokeStyle = 'rgba(0,0,0,.18)'; c.lineWidth = 1.5;
    for (i = -10; i <= 10; i++) { c.beginPath(); c.moveTo(640 + i * 40, 430); c.lineTo(640 + i * 190, 720); c.stroke(); }
    for (i = 0; i < 6; i++) { var yy = 430 + Math.pow(i / 6, 1.6) * 290; c.beginPath(); c.moveTo(0, yy); c.lineTo(1280, yy); c.stroke(); }
    c.fillStyle = '#d8d0c2'; c.fillRect(0, 420, 1280, 14);
    return cv;
  }

  /* ---------- UI ---------- */
  var CSS = ':host{all:initial}*{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}' +
    '.fab{position:fixed;right:18px;bottom:18px;z-index:2147483000;background:var(--b);color:#fff;border:0;border-radius:999px;padding:14px 20px;font-weight:700;font-size:15px;box-shadow:0 8px 24px rgba(0,0,0,.3);cursor:pointer}' +
    '.ov{position:fixed;inset:0;background:rgba(10,10,25,.62);z-index:2147483001;display:none;align-items:flex-end;justify-content:center}.ov.open{display:flex}' +
    '.pn{position:relative;background:#fff;color:#1b1b22;width:100%;max-width:1000px;max-height:96vh;overflow:auto;border-radius:18px 18px 0 0}' +
    '.inl .pn{border-radius:16px;max-height:none;border:1px solid #e4e4ee}' +
    '.hd{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid #eee;position:sticky;top:0;background:#fff;z-index:3}.hd h2{margin:0;font-size:17px}' +
    '.x{border:0;background:#f1f1f6;border-radius:50%;width:34px;height:34px;font-size:18px;cursor:pointer}' +
    '.g>div{min-width:0}.g{display:grid;gap:14px;padding:14px 16px 18px}@media(min-width:860px){.g{grid-template-columns:minmax(0,1.25fr) minmax(0,1fr)}.ov{align-items:center}.pn{border-radius:18px}}' +
    '.st{position:relative;background:#14141c;border-radius:12px;overflow:hidden;min-height:220px}.st canvas{display:block;width:100%;height:auto;touch-action:none;cursor:crosshair}' +
    '.emp{position:absolute;inset:0;display:flex;flex-direction:column;gap:10px;align-items:center;justify-content:center;color:#cfcfe0;text-align:center;padding:16px;font-size:14px}' +
    '.st.has .emp{display:none}.ai{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000;display:none}.st.vai .ai{display:block}' +
    '.hint{font-size:12px;color:#777;margin-top:6px}.tabs{display:none;gap:6px;margin-top:8px}.tabs.on{display:flex}' +
    '.lb{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:#666;margin:12px 0 6px}.lb:first-child{margin-top:0}' +
    '.row{display:flex;flex-wrap:wrap;gap:8px}.sc{display:flex;gap:8px;overflow-x:auto;padding-bottom:4px}' +
    'button.b,label.b{border:1.5px solid #dcdce8;background:#fff;color:#1b1b22;border-radius:10px;padding:9px 12px;font-size:14px;cursor:pointer;font-weight:600;display:inline-flex;gap:6px;align-items:center;white-space:nowrap}' +
    '.b.sel{border-color:var(--b);background:color-mix(in srgb,var(--b) 12%,#fff);color:var(--b)}.b.p{background:var(--b);border-color:var(--b);color:#fff}.b[disabled]{opacity:.55}' +
    '.sl{display:flex;align-items:center;gap:10px;font-size:13px;margin:4px 0}.sl span{width:70px;color:#555}.sl input{flex:1;accent-color:var(--b)}' +
    'input.t{width:100%;padding:10px 12px;border:1.5px solid #dcdce8;border-radius:10px;font-size:15px}' +
    '.toast{position:sticky;bottom:10px;margin:0 16px;background:#1b1b22;color:#fff;padding:10px 14px;border-radius:10px;font-size:13px;display:none}.toast.on{display:block}' +
    '.sp{width:16px;height:16px;border:2.5px solid #fff5;border-top-color:#fff;border-radius:50%;animation:r .8s linear infinite}@keyframes r{to{transform:rotate(1turn)}}' +
    '.pw{font-size:11px;color:#999;text-align:center;padding:0 0 10px}';

  function init() {
    var inline = CFG.mode === 'inline', mount = inline ? document.getElementById(CFG.target) : null;
    if (inline && !mount) { console.warn('[EventDecorAI] inline target #' + CFG.target + ' not found'); return; }
    var host = document.createElement('div'); (mount || document.body).appendChild(host);
    var root = host.attachShadow({ mode: 'open' });
    var chipsT = Object.keys(THEMES).map(function (k) { return '<button class="b" data-th="' + k + '">' + THEMES[k].emoji + ' ' + THEMES[k].name + '</button>'; }).join('');
    var chipsE = Object.keys(LABEL).map(function (k) { return '<button class="b" data-el="' + k + '">' + LABEL[k] + '</button>'; }).join('');
    var panel = '<div class="pn"><div class="hd"><h2>' + esc(CFG.title) + '</h2>' + (inline ? '' : '<button class="x" data-a="close" aria-label="Close">×</button>') + '</div>' +
      '<div class="g"><div><div class="st" id="st"><canvas id="cv" width="1280" height="720"></canvas><img class="ai" id="ai" alt="AI render"><div class="emp"><div style="font-size:34px">🏛️</div><div>Venue ki photo upload karo ya live camera chalao</div></div></div>' +
      '<div class="tabs" id="tabs"><button class="b sel" data-v="live">Live preview</button><button class="b" data-v="ai">AI render</button></div>' +
      '<div class="hint" id="hint">Tip: venue par tap/drag karke arch, backdrop aur candles ki jagah badlo.</div></div>' +
      '<div><div class="lb">1 · Venue</div><div class="row"><label class="b">📷 Upload photo<input type="file" accept="image/*" id="file" hidden></label><button class="b" data-a="cam">🎥 Live camera</button><button class="b" data-a="cap" id="cap" style="display:none">📸 Capture</button>' + (CFG.sample === 'true' ? '<button class="b" data-a="sample">🏛️ Sample venue</button>' : '') + '</div>' +
      '<div class="lb">2 · Theme</div><div class="sc">' + chipsT + '</div>' +
      '<div class="lb">3 · Decor elements</div><div class="row">' + chipsE + '</div>' +
      '<div class="lb">4 · Adjust</div><div class="sl"><span>Intensity</span><input type="range" id="int" min="20" max="100" value="75"></div><div class="sl"><span>Size</span><input type="range" id="size" min="60" max="140" value="100"></div>' +
      '<div class="lb">Name / text on backdrop</div><input class="t" id="txt" maxlength="30" placeholder="e.g. Riya &amp; Aman">' +
      '<div class="lb">5 · Finish</div><div class="row"><button class="b p" data-a="ai" id="aib">🤖 AI realistic render</button><button class="b" data-a="dl">⬇ Download</button>' + (CFG.whatsapp ? '<button class="b" data-a="enq">💬 Enquire</button>' : '') + '</div></div></div>' +
      '<div class="toast" id="toast"></div><div class="pw">Preview is indicative — final décor may vary.</div></div>';
    root.innerHTML = '<style>' + CSS + '</style><div id="w" style="--b:' + esc(CFG.brand) + '" class="' + (inline ? 'inl' : '') + '">' +
      (inline ? panel : '<button class="fab" data-a="open">' + esc(CFG.button) + '</button><div class="ov" id="ov">' + panel + '</div>') + '</div>';
    var $ = function (s) { return root.querySelector(s); }, $$ = function (s) { return [].slice.call(root.querySelectorAll(s)); };
    var cv = $('#cv'), ctx = cv.getContext('2d'), st = $('#st'), aiImg = $('#ai'), toastEl = $('#toast'), ov = $('#ov');
    var S = { theme: 'royal', on: {}, intensity: .75, scale: 1, ax: .5, ay: .86, text: '', view: 'live', result: '' };
    var base = null, stream = null, video = null, raf = 0, last = 0, isOpen = inline, tt;

    function esc(s) { return String(s).replace(/[&<>"]/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
    function toast(m) { toastEl.textContent = m; toastEl.classList.add('on'); clearTimeout(tt); tt = setTimeout(function () { toastEl.classList.remove('on'); }, 4000); }
    function setTheme(k) { S.theme = k; S.on = { ambience: true }; THEMES[k].on.forEach(function (e) { S.on[e] = true; }); sync(); }
    function sync() {
      $$('[data-th]').forEach(function (b) { b.classList.toggle('sel', b.dataset.th === S.theme); });
      $$('[data-el]').forEach(function (b) { b.classList.toggle('sel', !!S.on[b.dataset.el]); });
    }
    function setBase(b) { base = b; var sc2 = Math.min(1, 1280 / b.w); cv.width = Math.round(b.w * sc2); cv.height = Math.round(b.h * sc2); st.classList.add('has'); setView('live'); }
    function setView(v) { S.view = v; st.classList.toggle('vai', v === 'ai'); $$('[data-v]').forEach(function (b) { b.classList.toggle('sel', b.dataset.v === v); }); }
    function stopCam() { if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; } $('#cap').style.display = 'none'; }
    function loadFile(f) {
      if (!f) return; stopCam(); var img = new Image(), url = URL.createObjectURL(f);
      img.onload = function () { setBase({ el: img, w: img.naturalWidth, h: img.naturalHeight }); }; img.onerror = function () { toast('Image load nahi hui'); }; img.src = url;
    }
    function startCam() {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return toast('Camera is browser mein available nahi');
      navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false }).then(function (s) {
        stopCam(); stream = s; video = document.createElement('video'); video.muted = true; video.setAttribute('playsinline', ''); video.style.display = 'none'; root.appendChild(video); video.srcObject = s;
        return video.play().then(function () { setBase({ el: video, w: video.videoWidth || 1280, h: video.videoHeight || 720 }); $('#cap').style.display = ''; });
      }).catch(function (e) { toast('Camera chalu nahi hua (' + (e && e.name) + '). Photo upload use karo.'); });
    }
    function capture() { if (!base) return; var c2 = document.createElement('canvas'); c2.width = cv.width; c2.height = cv.height; c2.getContext('2d').drawImage(base.el, 0, 0, c2.width, c2.height); stopCam(); setBase({ el: c2, w: c2.width, h: c2.height }); }
    function snapshot() { var m = Math.min(1, 1024 / Math.max(cv.width, cv.height)), c2 = document.createElement('canvas'); c2.width = Math.round(cv.width * m); c2.height = Math.round(cv.height * m); c2.getContext('2d').drawImage(base.el, 0, 0, c2.width, c2.height); return c2.toDataURL('image/jpeg', .88); }
    function prompt_() {
      var th = THEMES[S.theme], els = Object.keys(S.on).filter(function (k) { return S.on[k] && AIEL[k]; }).map(function (k) { return AIEL[k]; });
      return 'Edit this photo of an event venue. Keep the space, architecture, camera angle and perspective exactly as in the photo. Decorate it for ' + th.ai + '. Include: ' + els.join(', ') + '.' + (S.text ? ' Show the text "' + S.text + '" on the backdrop or sign.' : '') + ' Photorealistic professional event photography, realistic scale and natural lighting. Do not add people.';
    }
    function aiRender() {
      if (!base) return toast('Pehle venue ki photo upload karo');
      if (!CFG.api) return toast('AI render ke liye data-api (backend URL) set karna hoga. Live preview kaam kar raha hai.');
      var b = $('#aib'), old = b.innerHTML; b.disabled = true; b.innerHTML = '<span class="sp"></span> Rendering…';
      fetch(CFG.api, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ image: snapshot(), prompt: prompt_(), theme: S.theme }) })
        .then(function (r) { if (!r.ok) throw new Error('Server ' + r.status); return r.json(); })
        .then(function (j) { if (!j.image) throw new Error(j.error || 'No image returned'); S.result = j.image; aiImg.src = j.image; $('#tabs').classList.add('on'); setView('ai'); })
        .catch(function (e) { toast('AI render fail: ' + e.message); })
        .then(function () { b.disabled = false; b.innerHTML = old; });
    }
    function download() {
      var a = document.createElement('a'); a.download = 'event-decor-preview.png';
      if (S.view === 'ai' && S.result) { a.href = S.result; a.click(); return; }
      if (!base) return toast('Pehle photo upload karo');
      cv.toBlob(function (bl) { a.href = URL.createObjectURL(bl); a.click(); }, 'image/png');
    }
    function enquire() {
      var th = THEMES[S.theme], els = Object.keys(S.on).filter(function (k) { return S.on[k] && LABEL[k]; }).map(function (k) { return LABEL[k]; }).join(', ');
      window.open('https://wa.me/' + String(CFG.whatsapp).replace(/\D/g, '') + '?text=' + encodeURIComponent('Hi! I tried the "' + th.name + '" decor (' + els + ') on your website. Please share a quote.'), '_blank');
    }
    function frame(ts) {
      raf = requestAnimationFrame(frame); if (!isOpen || !base || document.hidden || ts - last < 33) return; last = ts;
      if (base.el.readyState === 0) return;
      ctx.drawImage(base.el, 0, 0, cv.width, cv.height); drawScene(ctx, cv.width, cv.height, ts / 1000, S);
    }
    function open() { if (ov) ov.classList.add('open'); isOpen = true; if (!raf) raf = requestAnimationFrame(frame); }
    function close() { if (ov) ov.classList.remove('open'); isOpen = false; stopCam(); }
    function place(e) { var r = cv.getBoundingClientRect(); S.ax = Math.min(.95, Math.max(.05, (e.clientX - r.left) / r.width)); S.ay = Math.min(.97, Math.max(.3, (e.clientY - r.top) / r.height)); }

    root.addEventListener('click', function (e) {
      var t = e.target.closest('[data-a],[data-th],[data-el],[data-v]'); if (!t) return;
      if (t.dataset.th) return setTheme(t.dataset.th);
      if (t.dataset.el) { S.on[t.dataset.el] = !S.on[t.dataset.el]; return sync(); }
      if (t.dataset.v) return setView(t.dataset.v);
      ({ open: open, close: close, cam: startCam, cap: capture, ai: aiRender, dl: download, enq: enquire, sample: function () { stopCam(); setBase({ el: sampleVenue(), w: 1280, h: 720 }); } })[t.dataset.a]();
    });
    if (ov) ov.addEventListener('mousedown', function (e) { if (e.target === ov) close(); });
    $('#file').addEventListener('change', function (e) { loadFile(e.target.files[0]); e.target.value = ''; });
    $('#int').addEventListener('input', function (e) { S.intensity = e.target.value / 100; });
    $('#size').addEventListener('input', function (e) { S.scale = e.target.value / 100; });
    $('#txt').addEventListener('input', function (e) { S.text = e.target.value; });
    cv.addEventListener('pointerdown', function (e) { cv.setPointerCapture(e.pointerId); place(e); });
    cv.addEventListener('pointermove', function (e) { if (e.buttons) place(e); });

    setTheme('royal');
    window.EventDecorAI = { open: open, close: close };
    if (inline) raf = requestAnimationFrame(frame);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
