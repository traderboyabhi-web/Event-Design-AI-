// Netlify Function: AI render proxy  ->  POST /api/render
// Env vars (Netlify > Site settings > Environment variables):
//   OPENAI_API_KEY   (required for AI render)
//   ALLOWED_ORIGINS  (optional, comma separated, e.g. https://client.com)  default: any
//   IMAGE_MODEL      (optional, default gpt-image-1)  -- provider docs se confirm kar lena
export const config = { path: '/api/render' };

const H = { 'Content-Type': 'application/json' };
const out = (o, s = 200, extra = {}) => new Response(JSON.stringify(o), { status: s, headers: { ...H, ...extra } });

export default async (req) => {
  const origin = req.headers.get('origin') || '';
  const allowed = (process.env.ALLOWED_ORIGINS || '*').split(',').map((s) => s.trim());
  const ok = allowed.includes('*') || allowed.includes(origin);
  const cors = { 'Access-Control-Allow-Origin': ok ? origin || '*' : 'null', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
  if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
  if (req.method !== 'POST' || !ok) return out({ error: 'forbidden' }, 403, cors);
  if (!process.env.OPENAI_API_KEY) return out({ error: 'OPENAI_API_KEY not set' }, 500, cors);

  let body; try { body = await req.json(); } catch { return out({ error: 'bad json' }, 400, cors); }
  const { image, prompt } = body || {};
  if (!image || !prompt || !/^data:image\/(jpeg|png|webp);base64,/.test(image)) return out({ error: 'bad input' }, 400, cors);
  if (image.length > 5_600_000) return out({ error: 'image too large' }, 413, cors);

  const bin = Buffer.from(image.split(',')[1], 'base64');
  const fd = new FormData();
  fd.append('model', process.env.IMAGE_MODEL || 'gpt-image-1');
  fd.append('image', new Blob([bin], { type: 'image/jpeg' }), 'venue.jpg');
  fd.append('prompt', String(prompt).slice(0, 1500));
  fd.append('size', 'auto');

  const r = await fetch('https://api.openai.com/v1/images/edits', { method: 'POST', headers: { Authorization: 'Bearer ' + process.env.OPENAI_API_KEY }, body: fd });
  if (!r.ok) return out({ error: 'provider ' + r.status }, 502, cors);
  const j = await r.json(); const b64 = j?.data?.[0]?.b64_json;
  if (!b64) return out({ error: 'no image from provider' }, 502, cors);
  return out({ image: 'data:image/png;base64,' + b64 }, 200, cors);
};
