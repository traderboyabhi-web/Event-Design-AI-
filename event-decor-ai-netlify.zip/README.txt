NETLIFY DEPLOY
1. app.netlify.com > Add new site > Deploy manually > is folder/zip ko drag-drop karo.
2. Live preview turant chalega (index.html).
3. AI render ke liye: Site settings > Environment variables > OPENAI_API_KEY add karo, phir redeploy.
   Note: functions ke saath drag-drop kabhi kabhi kaam nahi karta; us case mein GitHub repo se connect karke deploy karo.
CLIENT SITE MEIN: us site par yeh tag lagao (apna Netlify URL daalo):
<script src="https://YOUR-SITE.netlify.app/event-decor-ai.js" data-api="https://YOUR-SITE.netlify.app/api/render" data-whatsapp="91XXXXXXXXXX" data-brand="#c026d3"></script>
Production mein ALLOWED_ORIGINS env var mein client domains daalo.
